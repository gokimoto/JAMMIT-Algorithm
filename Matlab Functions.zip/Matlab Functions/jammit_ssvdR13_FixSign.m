function [U1 U2 U3 V] = ssvdR13_FixSign(A,B,C,alpha)
% Usage: [U1,U2,U3,V] = ssvdR13_FixSign(A,B,C,alpha)
% Input: A = P1xN data matrix
%        B = P2xN data matrix
%        C = P3xN data matrix
%        alpha = l1 sparsity parameter
% Output: U1 = Loading vector for A
%         U2 = Loading vector for B
%         U3 = Loading vector for C
%          V = Scores for dominant signal of the stacked
%              matrix [A;B;C]
% Description: Computes sparse, rank-1 approximation of the 
%              stacked matrix [A;B;C].
% Get dimensions of data matrices
[m1,n1]=size(A);
[m2,n2]=size(B);
[m3,n3]=size(C);

% Check that data matrices have the same number of columns
if (n1==n2 & n2==n3)
    n=n1;
else
    fprintf('The data should have the same number of columns \n');
    U1=[];
    U2=[];
    U3=[];
    V=[];
    return;
end;

% Form stacked matrix
X=[A;B;C];

% Set initial state vector
[t1 t2 t3] = svd(X,'econ');
u0 = t1(:,1);%initial value of left singular vector
ud = 1;%ud is used to to decide convergence
iter_cnt = 0; %number of iterations

% Fix sign of initial state vector
mu = mean(X)';
t31 = t3(:,1);
corrmut31 = corr(mu,t31);
if corrmut31 <= 0
    u0 = -u0;
end

% Compute sparse rank-1 approximation of the stacked matrix
while (ud > 0.0001) 
    iter_cnt = iter_cnt+1;    
    v =  X'*u0/sqrt(sum((X'*u0).^2)); % update v    
    u = sign(X*v).*max(abs(X*v)-alpha,0); % update u
    s = sqrt(sum(u.^2)); % singular value
    u = u/s; % normalizing u    
    ud = sqrt(sum((u0-u).^2)); % ud=||u-u0||
    u0 = u;
    if iter_cnt > 5000 % 5000 is the maximum number of iterations
        disp('Fail to converge! Increase the limit on the maximum number of iterations')
        break
    end   
end

% Set output variables
V=sqrt(sum((X'*u).^2))*v;
U1=u(1:m1);
U2=u(m1+1:m1+m2);
U3=u(m1+m2+1:m1+m2+m3);