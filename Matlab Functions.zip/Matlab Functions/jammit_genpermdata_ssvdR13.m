function y = genpermdata_ssvdR13(A,B,C,nperms)
% y = permdata_ssvdR13(A,B,C,nperms)
szA = size(A);
szB = size(B);
szC = size(C);

nrowsA = szA(1);
nrowsB = szB(1);
nrowsC = szC(1);

y = cell(nperms,3);

for ii = 1:nperms
    Aperm = rowresamp(A,1);
    Bperm = rowresamp(B,1);
    Cperm = rowresamp(C,1);
    
    y{ii,1} = Aperm;
    y{ii,2} = Bperm;
    y{ii,3} = Cperm;
end

