function y = efdr_ssvdR12(A,B,nsuppA,nsuppB,alphavec,nperms)
% Usage: y = efdr_ssvdR12(A,B,nsuppA,nsuppB,alphavec,nperms)
% Input: A = data matrix 1; B = data matrix 2
%   nsuppA = estimated support for top signal in A
%   nsuppB =     "        "     "   "    "     " B
%   alphavec = vector of l1 sparsity parameters 
%   nperms = number of permutations
% Output: y = struct('fdrAall',fdrAall,'fdrBall',fdrBall,...
%   'nsigAall',nsigAall,'nsigBall',nsigBall,'alphavec',alphavec,...
%   'pi0A',pi0A,'pi0B',pi0B,'nperms',nperms);

disp('Start FDR estimation!!');
tstart = tic;

% Initialize variables
szA = size(A);
nrowsA = szA(1);
szB = size(B);
nrowsB = szB(1);
ncols = szA(2);
pi0A = 1-(nsuppA/nrowsA);
pi0B = 1-(nsuppB/nrowsB);
pi0AB = 1-((nsuppA+nsuppB)/(nrowsA+nrowsB));
nalpha = length(alphavec);

% Initialize tracking variables
fdrAall = zeros(nalpha,1);
nsigAall = zeros(nalpha,1);
fdrBall = zeros(nalpha,1);
nsigBall = zeros(nalpha,1);
fdrABall = zeros(nalpha,1);
nsigABall = zeros(nalpha,1);

% Loop through the alphas
for ii = 1:nalpha
    ii
    % Initialize variables
    nsigAii = zeros(nperms,1);
    nsigBii = zeros(nperms,1);
    nsigABii = zeros(nperms,1);
    
    % Select alpha and initialize tracking variables
    alpha = alphavec(ii);
        
    % Compute l1-svd of original data
    [uii,vii,xii] = ssvdR12_FixSign(A,B,alpha);
    
    % Find number of siggenes in original data
    nsiguii = length(find(abs(uii)>0));
    nsigvii = length(find(abs(vii)>0));
    nsigAall(ii) = nsiguii;
    nsigBall(ii) = nsigvii;
    nsigABall(ii) = nsiguii+nsigvii;
    % Compute residuals wrt l1 solution based on selected alpha
    Aresid = A-uii*xii';
    Bresid = B-vii*xii';
    % Compute nperms permuted data sets based on residual data
    permdata = genpermdata_ssvdR12(Aresid,Bresid,nperms);
     
    % Begin looping through the permuted data
    for jj = 1:nperms
        %jj
        % Get permuted data
        rsdata = permdata(jj,:);
        Aperm = rsdata{1};
        Bperm = rsdata{2};
               
        % Do l1-svd on permuated data for selected alpha
        [ujj,vjj,xjj] = ssvdR12_FixSign(Aperm,Bperm,alpha);
        
        % Count false positives
        nsigajj = length(find(abs(ujj)>0));
        nsigbjj = length(find(abs(vjj)>0));
        nsigAii(jj) = nsigajj;
        nsigBii(jj) = nsigbjj;
        nsigABii(jj) = nsigajj+nsigbjj;
    end
    
    % Compute the median number of false positives over # perms
    medAii = mean(nsigAii); %median(nsigAii);
    medBii = mean(nsigBii); %median(nsigBii);
    medABii = mean(nsigABii); %median(nsigABii);
    
    % Compute estimated FDR with pi0 adjustment
    fdrAii = min(pi0A*medAii/nsigAall(ii),1);
    fdrBii = min(pi0B*medBii/nsigBall(ii),1);
    fdrABii = min(pi0AB*medABii/nsigABall(ii),1);
    
    % Load FDRs into variables
    fdrAall(ii) = fdrAii;
    fdrBall(ii) = fdrBii;
    fdrABall(ii) = fdrABii;
    fdrtab = [nsigAall fdrAall nsigBall fdrBall nsigABall fdrABall,alphavec'];
end

% A lot of output ... not all needed for production version
y = struct('fdrAall',fdrAall,'fdrBall',fdrBall,'fdrABall',fdrABall,...
    'nsigAall',nsigAall,'nsigBall',nsigBall,'nsigABall',nsigABall,...
    'alphavec',alphavec,'pi0A',pi0A,'pi0B',pi0B,'pi0AB',pi0AB,...
    'nperms',nperms,'fdrtab',fdrtab); 

disp('End FDR estimation!!');
telapsed = toc(tstart)
    
  
