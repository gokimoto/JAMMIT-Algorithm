function y = genpermdata_ssvdR12(A,B,nperms)
% Usage: y = permdata_ssvdR12(A,B,nperms)
% Input: A = P1xN data matrix
%        B = P2xN data matrix
%        nperms = number of permutations
% Output: nperms-by-2 cell array y of row-permuted versions of A and B
% Description: This function generates a nperms-by-2 cell array where
% y(:,1) is a cell array of row-permuted versions of A and y(:,2) is a cell
% array of row-permuted versions of B.

% Get dimensions of A and B
szA = size(A);
szB = size(B);

% Initialize variables
nrowsA = szA(1);
nrowsB = szB(1);
ncolsA = szA(2);
ncolsB = szB(2);

y = cell(nperms,2);

for ii = 1:nperms
    Aperm = rowresamp(A,1);
    Bperm = rowresamp(B,1);
    y{ii,1} = Aperm;
    y{ii,2} = Bperm;
end

