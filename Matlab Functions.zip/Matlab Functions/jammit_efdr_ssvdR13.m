function y = efdr_ssvdR13(A,B,C,nsuppA,nsuppB,nsuppC,alphavec,nperms)
% Usage: y = efdr_ssvdR13(A,B,C,nsuppA,nsuppB,nsuppC,alphavec,nperms)
% Input: - A, B, and C are data matrices with the same number of columns
%        - nsuppA, nsuppB, and nsuppC = estimated support for top signals in
%          data matrices A, B, and C.
%        - alphavec = vector of alpha values   
%        - nperms = number of permutations
% Output: y = struct('...
%    fdrAall',fdrAall,'fdrBall',fdrBall,'fdrCall',fdrCall,...
%   'nsigAall',nsigAall,'nsigBall',nsigBall,'nsigCall',nsigCall,...
%   'alphavec',alphavec,'pi0A',pi0A,'pi0B',pi0B,'nperms',nperms);

disp('Start FDR estimation!!');
tstart = tic;

% Initialize variables
szA = size(A);
nrowsA = szA(1);
szB = size(B);
nrowsB = szB(1);
szC = size(C);
nrowsC = szC(1);
ncols = szA(2);
nalpha = length(alphavec);
% alphavec = linspace(0,1,nalpha);
% % Compute std of stack
% ABC = [A;B;C];
% maxABC = max(ABC(:));
% alphavec = maxABC.*alphavec;

pi0A = 1-(nsuppA/nrowsA);
pi0B = 1-(nsuppB/nrowsB);
pi0C = 1-(nsuppC/nrowsC);
pi0ABC = 1-((nsuppA+nsuppB+nsuppC)/(nrowsA+nrowsB+nrowsC));

% Initialize tracking variables
fdrAall = zeros(nalpha,1);
nsigAall = zeros(nalpha,1);
fdrBall = zeros(nalpha,1);
nsigBall = zeros(nalpha,1);
fdrCall = zeros(nalpha,1);
nsigCall = zeros(nalpha,1);
fdrABCall = zeros(nalpha,1);
nsigABCall = zeros(nalpha,1);

% Loop through the alphas
for ii = 1:nalpha
    ii
    % Initialize variables
    nsigAii = zeros(nperms,1);
    nsigBii = zeros(nperms,1);
    nsigCii = zeros(nperms,1);
    nsigABCii = zeros(nperms,1);
    
    % Select alpha and initialize tracking variables
    alpha = alphavec(ii);
        
    % Compute l1-svd of original data
    [uAii,uBii,uCii,xii] = ssvdR13new(A,B,C,alpha);
    
%     isnanA = isnan(uii);
%     nnanA = length(find(isnanA == 1));
%     isnanB = isnan(vii);
%     nnanB = length(find(isnanB == 1));
%     nnanAB = nnanA+nnanB;
%     isnanX = isnan(xii);
%     nnanX = length(find(isnanX == 1));
        
%     if nnanAB == 0
%         % Find number of siggenes in original data
%         nsiguii = length(find(abs(uii)>0));
%         nsigvii = length(find(abs(vii)>0));
%         nsigAall(ii) = nsiguii;
%         nsigBall(ii) = nsigvii;
%         nsigABall(ii) = nsiguii+nsigvii;
%         % Compute residuals wrt l1 solution based on selected alpha
%         Aresid = A-uii*xii';
%         Bresid = B-vii*xii';
%         % Compute nperms permuted data sets based on residual data
%         permdata = genpermdata_ssvdR12(Aresid,Bresid,nperms);
% 
%     else
%         uii = zeros(nrowsA,1);
%         vii = zeros(nrowsB,1);
%         xii = zeros(1,ncols);
%     end

    % Find number of siggenes in original data
    nsiguAii = length(find(abs(uAii)>0));
    nsiguBii = length(find(abs(uBii)>0));
    nsiguCii = length(find(abs(uCii)>0));
    
    nsigAall(ii) = nsiguAii;
    nsigBall(ii) = nsiguBii;
    nsigCall(ii) = nsiguCii; 
    nsigABCall(ii) = nsiguAii+nsiguBii+nsiguCii;
        
    % Compute residuals wrt l1 solution based on selected alpha
    Aresid = A; %A-uAii*xii';
    Bresid = B; %B-uBii*xii';
    Cresid = C; %C-uCii*xii';
    
    % Compute nperms permuted data sets based on residual data
    permdata = genpermdata_ssvdR13(Aresid,Bresid,Cresid,nperms);
     
    % Begin looping through the permuted data
    for jj = 1:nperms
        jj
        % Get permuted data
        rsdata = permdata(jj,:);
        Aperm = rsdata{1};
        Bperm = rsdata{2};
        Cperm = rsdata{3};
               
        % Do l1-svd on permuted data for selected alpha
        [uAjj,uBjj,uCjj,xjj] = ssvdR13new(Aperm,Bperm,Cperm,alpha);
        
        % Count false positives
        nsiguAjj = length(find(abs(uAjj)>0));
        nsiguBjj = length(find(abs(uBjj)>0));
        nsiguCjj = length(find(abs(uCjj)>0));
        
        nsigAii(jj) = nsiguAjj;
        nsigBii(jj) = nsiguBjj;
        nsigCii(jj) = nsiguCjj;
        nsigABCii(jj) = nsiguAjj+nsiguBjj+nsiguCjj;
    end
    
    % Compute the mean number of false positives over # perms
    medAii = mean(nsigAii); %median(nsigAii);
    medBii = mean(nsigBii); %median(nsigBii);
    medCii = mean(nsigCii);
    medABCii = mean(nsigABCii); %median(nsigABii);
    
    % Compute estimated FDR with pi0 adjustment
    fdrAii = min(pi0A*medAii/nsigAall(ii),1);
    fdrBii = min(pi0B*medBii/nsigBall(ii),1);
    fdrCii = min(pi0C*medCii/nsigCall(ii),1);
    fdrABCii = min(pi0ABC*medABCii/nsigABCall(ii),1);
    
    % Load FDRs into variables
    fdrAall(ii) = fdrAii;
    fdrBall(ii) = fdrBii;
    fdrCall(ii) = fdrCii;
    fdrABCall(ii) = fdrABCii;
    fdrtab = [nsigAall fdrAall nsigBall fdrBall ...
        nsigCall fdrCall nsigABCall fdrABCall,alphavec'];
end

% A lot of output ... not all needed for production version
y = struct('fdrAall',fdrAall,'fdrBall',fdrBall,'fdrCall',fdrCall,...
    'fdrABCall',fdrABCall,'nsigAall',nsigAall,'nsigBall',nsigBall,...
    'nsigCall',nsigCall,'nsigABCall',nsigABCall,'alphavec',alphavec,...
    'pi0A',pi0A,'pi0B',pi0B,'pi0C',pi0C,'pi0ABC',pi0ABC,'nperms',nperms,...
    'fdrtab',fdrtab); 

disp('End FDR estimation!!');
telapsed = toc(tstart)
    
  
